package com.nt.dto;

import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

public class Register {
	@NotBlank(message = "Please fill in the name")
	@Size(min = 3, max = 15, message = "Name must be between 3 and 15 characters")
	private String name;

	@NotBlank(message = "Please fill in the password")
	@Size(min = 3, max = 15, message = "Password must be between 3 and 15 characters")
	private String pass;

	private String country;

	@NotEmpty(message = "Please select at least one hobby")
	private String[] hobbies;

	@NotBlank(message = "Please select a gender")
	private String gender;

	public String getPass() {
		return pass;
	}

	public void setPass(String pass) {
		this.pass = pass;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getName() {
		return name;
	}

	public String[] getHobbies() {
		return hobbies;
	}

	public void setHobbies(String[] hobbies) {
		this.hobbies = hobbies;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCountry() {
		return country;
	}

}
