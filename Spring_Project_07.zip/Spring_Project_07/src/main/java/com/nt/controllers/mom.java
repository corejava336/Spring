package com.nt.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class mom {

    @RequestMapping("/sugar")
    public String sugar(Model model) {
        return "Home";
    }

}
