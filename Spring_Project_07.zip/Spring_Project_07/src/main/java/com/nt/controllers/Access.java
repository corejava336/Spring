package com.nt.controllers;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.nt.dto.Register;
import com.nt.dto.login;


@Controller
public class Access {

	@RequestMapping("/login")
	public String login(@ModelAttribute("login") login login) {
		// Implement your login logic here
		return "Home";
	}

	@PostMapping("/process")
	public String process(@ModelAttribute("login") login login) {
		// Implement your login logic here
		if ("lee".equals(login.getName()) && "123".equals(login.getPass())) {
			return "sucess";

		} else {
			return "Home";

		}
	}

	@RequestMapping("/CRegister")
	public String CRegister(@Valid Model model) {
		model.addAttribute("register", new Register());
		return "Register";
	}

	@PostMapping("/registerUser")
	public String Register(@Valid @ModelAttribute("register") Register register, BindingResult result, Model m) {
		System.out.println(register.getCountry()+" "+ register.getName()+" "+ register.getPass());
		System.out.println(result.getFieldErrorCount());
		if (result.hasErrors()) {
			System.out.println(" errors are present");
			return "Register"; // Return to the registration page to display errors
		}
		return "RSucess"; // Success page
	}

}
