package com.nt.cofiguration;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.stereotype.Controller;
import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

@Controller
public class WebCfg implements WebApplicationInitializer {

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		// TODO Auto-generated method stub
		AnnotationConfigWebApplicationContext web = new AnnotationConfigWebApplicationContext();
		web.register(AppCfg.class);
		DispatcherServlet dsp = new DispatcherServlet(web);
		ServletRegistration.Dynamic dynamic = servletContext.addServlet("dada", dsp);
		dynamic.setLoadOnStartup(1);
		dynamic.addMapping("/Home.com/*");

	}

}
